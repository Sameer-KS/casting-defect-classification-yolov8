from ultralytics import YOLO
import cv2

model = YOLO("best.pt")

results = model("casting_512x512/def_front/cast_def_0_9854.jpeg")
class_names = model.names
print(class_names)
confidence_rates = {name: 0 for name in class_names.values()}
print(confidence_rates)

for r in results:
    detected_object = int(r.probs.top1)
    # print(detected_object)
    detectet_object_name  = class_names[detected_object]
    # print(detectet_object_name)  # print the labels of the detected objects

    # print(r.probs.data)  # print the probabilities of the detected objects
    detected_object_confidence_rate = r.probs.data[detected_object].item()
    # print(detected_object_confidence_rate)  # print the confidence rate of the detected objects

    detection_info = f"{detectet_object_name}: {detected_object_confidence_rate:.4f}"
    print(detection_info)  # print the detection information

    
