import customtkinter as ctk
from tkinter import filedialog
from PIL import Image, ImageTk
from ultralytics import YOLO
import cv2


class ImageApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Detection App")
        self.root.geometry("720x720")

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        # Main frame holding both panels
        self.main_frame = ctk.CTkFrame(root, fg_color="transparent", width=900, height=900)
        self.main_frame.pack(pady=40, padx=40, expand=True)

        self.frame = self.main_frame

        # Left panel: original image + Add Image button
        self.left_frame = ctk.CTkFrame(self.frame, fg_color=("white", "gray20"), width=400, height=400)
        self.left_frame.pack(side="left", padx=10, expand=True)

        self.image_label_left = ctk.CTkLabel(self.left_frame, text="")
        self.image_label_left.pack(pady=(10, 5))

        self.add_img_btn = ctk.CTkButton(self.left_frame, text="Add Image", command=self.add_image)
        self.add_img_btn.pack(pady=(5, 10))

        # Right panel: result image + Show Results button
        self.right_frame = ctk.CTkFrame(self.frame, fg_color=("white", "gray20"), width=400, height=400)
        self.right_frame.pack(side="right", padx=10, expand=True)

        self.image_label_right = ctk.CTkLabel(self.right_frame, text="")
        self.image_label_right.pack(pady=(10, 5))

        self.show_results_btn = ctk.CTkButton(self.right_frame, text="Show Results", command=self.show_results)
        self.show_results_btn.pack(pady=(5, 10))

        self.image_path = ""
        self.original_image = None
        self.modified_image = None

    def add_image(self):
        self.image_path = filedialog.askopenfilename(
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp")]
        )
        if self.image_path:
            self.original_image = cv2.imread(self.image_path)
            self.display_image(self.original_image, self.image_label_left)

    def show_results(self):
        if self.original_image is not None:
            model = YOLO("best.pt")
            results = model(self.original_image)
            class_names = model.names

            detection_info = ""
            for r in results:
                detected_object = int(r.probs.top1)
                detected_object_name = class_names[detected_object]
                detected_object_confidence_rate = r.probs.data[detected_object].item()
                detection_info = f"{detected_object_name}: {detected_object_confidence_rate:.4f}"
                print(detection_info)

            self.modified_image = self.original_image.copy()
            h, w, _ = self.modified_image.shape
            text_position = (w // 2, h // 8)
            text_color = (0, 0, 255)
            text_font = cv2.FONT_HERSHEY_SIMPLEX
            text_scale = 1
            text_thickness = 2
            cv2.putText(
                self.modified_image, detection_info, text_position,
                text_font, text_scale, text_color, text_thickness
            )

            self.display_image(self.modified_image, self.image_label_right)
            self.image_label_right.configure(text=detection_info)
            self.image_label_right.pack()

    def display_image(self, img, label):
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(img)
        img = img.resize((300, 300), Image.Resampling.LANCZOS)
        ctk_image = ctk.CTkImage(light_image=img, dark_image=img, size=(300, 300))
        label.configure(image=ctk_image)
        label.image = ctk_image  # keep a reference to avoid garbage collection


if __name__ == "__main__":
    root = ctk.CTk()
    app = ImageApp(root)
    root.mainloop()